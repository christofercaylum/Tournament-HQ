# Tournament HQ V8.5.4 RC3 — Readiness & Print Center Cleanup

Based on the working V8.5.4 RC2. This release changes presentation only.

## Changes
- Print Center prioritizes printable reports and packets; its existing Test Print Controls button now lives in a collapsed Advanced diagnostics section.
- Readiness includes direct shortcuts to Registrations, Officials, and Print Center.
- Export & Recovery and Audit History are available in collapsed Advanced sections instead of consuming the entire Health Check screen.
- No scoring, roster, reporting, or cloud functions changed. No SQL or Edge Function changes required.

## Install and test
1. Keep your V8.5.4 RC2 backup. Replace GitHub Pages index.html with this release.
2. Refresh and confirm the header reads V8.5.4 RC3.
3. Check Prepare → Readiness → Health Check for working shortcuts and expandable backup/audit sections.
4. Check Print Center: printable reports first and Advanced → Print diagnostics still works.
5. Confirm QR signs, referee links, and court packet printing remain present.

JS syntax validation is performed at build time, but cloud and browser functionality need live verification.
