# Harvest Crown HQ V4 — release candidate

This package contains:
- `index.html`: the mobile-first director, referee, captain, and public-display app; local practice mode still works without cloud.
- `cloud.sql`: database schema and server-checked access operations for a **new, dedicated Supabase project**.
- This README.

## IMPORTANT
This is a **release candidate, not a certified live tournament system**. The browser's built-in JavaScript parser passed, but the cloud SQL and cross-device workflows have **not been deployed or end-to-end verified** against a Supabase project. Rehearse with simulated teams and scores before live use. Never overwrite your V3 file or existing Supabase project until verified.

## 1. Test offline first
Open `index.html` in a desktop browser. Use **Start Practice Tournament**, switch to Referee in the top mode control, report scores, approve them in Director, run Safety, and test bracket progression. Practice data is stored only in this browser (new v4 storage key), separate from V3. Export JSON backups under Setup.

## 2. Host in GitHub Pages
Create a repository (e.g. `harvest-crown-hq`), upload just `index.html` to root, set **Settings > Pages > Deploy from main / root**. Open the generated HTTPS URL in Safari and optionally Add to Home Screen. Static hosting makes the interface accessible; it **does not** synchronize data by itself.

## 3. Set up a separate Supabase project
1. Create a **new** Supabase project for tournament HQ (do not run this SQL in your Courtside Performance Lab project).
2. Open `cloud.sql`, replace `REPLACE_DIRECTOR@example.com` with the email you will use for director sign-in. Replace the assistant email with a real intended assistant or delete that INSERT row, and ensure valid SQL syntax. You can also change the placeholders after deployment using SQL commands in the dashboard.
3. Run `cloud.sql` in the Supabase SQL Editor. It makes private base tables, grants narrow RPC functions, and uses role verification from the signed-in email. Never grant broad write policies to `anon`.
4. Under Authentication > URL Configuration, allow your **actual GitHub Pages site URL** as a redirect. Configure email sign-in delivery. The project may impose email limits on built-in sending; use proper SMTP if necessary. No referee email sign-ins are required.
5. Under Project Settings > API, copy the project URL and **publishable/anon key** (NEVER service_role or secret key). In Director > Cloud, paste both and select Connect. Sign in using your authorized email.
6. In local practice, set up teams, courts, officials, generate and validate. Publish the schedule (`Published` or `Live` status) and select **Publish Practice Data** from an **authenticated director** browser. The first publish is a manual action. Confirm the display page loads published data from another browser.
7. Use **Create Referee Link** in Cloud and specify the **exact** named referee or team (for team-provided officiating) already present in the published schedule. Copy the link immediately. Each referee opens their own link without signing in. You can revoke links by name and issue replacements. Do not paste referee links into public social posts.
8. Use another approved staff email in the `hq_staff` table to activate assistant-director score approval; assistants cannot publish setup changes. Test on separate devices.

### Score workflow in live mode
Referee link > choose assigned game > enter sets > Review Score > submit > cloud acknowledges a receipt. Director or assistant sees pending score and approves/rejects. Approved scores update standings and can advance brackets. Simultaneous updates are version checked. A score pending locally or with network errors is **not** confirmed received; do not re-enter blindly.

### Links
- Director: `https://YOURUSERNAME.github.io/harvest-crown-hq/`
- Display: `https://YOURUSERNAME.github.io/harvest-crown-hq/?mode=display`
- Referee: personalized link copied from Cloud page, containing an unguessable bearer token. Anyone possessing a link can act as that referee until revoked.

### Intended limitations / needs verification
- Cloud functions require Supabase deployment and manual end-to-end testing; SQL syntax and role policies were not tested against a live instance.
- Director changes rely on compare-and-swap state versioning; if a conflict occurs, export your local backup and reload. Do not assume unsynced changes were saved.
- Cloud-approved reports are atomic with state updates. Other practice functions inherited from V3 must be tested with real match scores and format permutations.
- Refs assigned as a **team** use a link issued to the exact team name, not individual names; this records team accountability rather than the identity of a particular person. For individual audit trails, assign a dedicated named referee instead.
- Offline referee submissions do not queue in the cloud. They must be retried with connectivity.
- Printed PDF schedule is not implemented; JSON and CSV export remain. Use browser Print to PDF for backups.
- Tournament time estimates remain provisional; weather, injuries, late matches and playoff entrants may require director intervention.
- Practice role switching is **not** real authentication. In live mode Supabase functions enforce server checks; the director UI can be displayed locally but its live write operations require a signed-in director account.

## Game-day rehearsal
1. Use seven teams / two courts, then test four and twelve teams in separate practice resets.
2. Test both dedicated referee and team-officiated schedules. Safety report must show no critical conflicts before publishing.
3. Publish test state, open public display in a private browser, open referee link on an iPhone, submit a score.
4. Approve on another authorized device; confirm scoreboard/standings update on display.
5. Correct a finished score and inspect dependencies; simulate conflicting changes from two director tabs.
6. Revoke a referee link and verify further submissions fail.
7. Turn off connectivity on referee phone: verify failure is explicit and nothing is marked submitted.
8. Test assistant email approval and verify setup changes are blocked.
9. Export JSON and CSV before and after tournament. Have printed court schedules and paper score sheets as fallback.
