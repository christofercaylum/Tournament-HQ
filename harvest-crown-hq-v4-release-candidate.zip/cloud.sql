-- HARVEST CROWN HQ V4 — fresh, dedicated Supabase project only.
-- 1. Replace BOTH email addresses below; delete the assistant row if unused.
-- 2. Execute once in Supabase SQL editor. Never put service-role keys in the app.
create extension if not exists pgcrypto;
create table if not exists public.hq_staff(email text primary key, role text not null check(role in ('director','assistant')));
insert into public.hq_staff(email,role) values
('REPLACE_DIRECTOR@example.com','director'),
('REPLACE_ASSISTANT@example.com','assistant')
on conflict(email) do update set role=excluded.role;
create table if not exists public.hq_state(id text primary key default 'harvest-crown', version bigint not null default 0, data jsonb not null, updated_at timestamptz not null default now());
create table if not exists public.hq_tokens(id uuid primary key default gen_random_uuid(), name text not null, secret_hash text unique not null, active boolean not null default true, created_at timestamptz default now());
create table if not exists public.hq_reports(id uuid primary key default gen_random_uuid(), match_id text not null, reporter text not null, token_id uuid references public.hq_tokens(id), sets jsonb not null, home text, away text, status text not null default 'pending' check(status in ('pending','approved','rejected')), created_at timestamptz not null default now(), decided_at timestamptz, decided_by text);
create table if not exists public.hq_activity(id bigint generated always as identity primary key, actor text not null, action text not null, details jsonb, happened_at timestamptz not null default now());
alter table public.hq_staff enable row level security;
alter table public.hq_state enable row level security;
alter table public.hq_tokens enable row level security;
alter table public.hq_reports enable row level security;
alter table public.hq_activity enable row level security;
revoke all on public.hq_staff,public.hq_state,public.hq_tokens,public.hq_reports,public.hq_activity from anon,authenticated;
create or replace function public.hq_my_role() returns text language sql stable security definer set search_path=public as $$ select role from public.hq_staff where lower(email)=lower(coalesce(auth.jwt()->>'email','')) limit 1 $$;
create or replace function public.hq_view() returns jsonb language plpgsql stable security definer set search_path=public as $$
declare d jsonb;
begin
 select data into d from public.hq_state where id='harvest-crown';
 if d is null then return null; end if;
 if public.hq_my_role() is not null then return jsonb_build_object('data',d,'role',public.hq_my_role(),'version',(select version from public.hq_state where id='harvest-crown')); end if;
 if d->>'status' not in ('published','live','completed') then return null; end if;
 return jsonb_build_object('data', d - 'audit' - 'reports','role','viewer','version',(select version from public.hq_state where id='harvest-crown'));
end $$;
create or replace function public.hq_save(p_data jsonb,p_expected bigint) returns bigint language plpgsql security definer set search_path=public as $$
declare v bigint;r text;
begin
 r:=public.hq_my_role();
 if r is distinct from 'director' then raise exception 'Only directors can publish tournament state'; end if;
 if p_data->>'schema' <> '2' or jsonb_typeof(p_data->'matches') <> 'array' or jsonb_typeof(p_data->'teams') <> 'array' then raise exception 'Invalid tournament data'; end if;
 insert into public.hq_state(id,version,data) values('harvest-crown',1,p_data) on conflict do nothing;
 if found then
  if p_expected <> 0 then raise exception 'Cloud already initialized: reload shared data'; end if;
  v:=1;
 else
  update public.hq_state set version=version+1,data=p_data,updated_at=now() where id='harvest-crown' and version=p_expected returning version into v;
  if v is null then raise exception 'Version conflict: load shared state before editing'; end if;
 end if;
 insert into public.hq_activity(actor,action,details) values(auth.jwt()->>'email','state_published',jsonb_build_object('version',v));
 return v;
end $$;
create or replace function public.hq_issue_token(p_name text) returns text language plpgsql security definer set search_path=public as $$
declare t text;
begin
 if public.hq_my_role() <> 'director' then raise exception 'Not authorized'; end if;
 if length(trim(p_name))<1 or length(p_name)>80 then raise exception 'Enter referee name (1-80 characters)'; end if;
 t:=encode(gen_random_bytes(24),'hex');
 insert into public.hq_tokens(name,secret_hash) values(trim(p_name),encode(digest(t,'sha256'),'hex'));
 insert into public.hq_activity(actor,action,details) values(auth.jwt()->>'email','ref_link_created',jsonb_build_object('referee',p_name));
 return t;
end $$;
create or replace function public.hq_revoke_token(p_name text) returns void language plpgsql security definer set search_path=public as $$
begin
 if public.hq_my_role() <> 'director' then raise exception 'Not authorized'; end if;
 update public.hq_tokens set active=false where name=p_name;
 insert into public.hq_activity(actor,action,details) values(auth.jwt()->>'email','ref_link_revoked',jsonb_build_object('referee',p_name));
end $$;
create or replace function public.hq_ref_identity(p_secret text) returns text language sql stable security definer set search_path=public as $$
 select name from public.hq_tokens where active=true and secret_hash=encode(digest(coalesce(p_secret,''),'sha256'),'hex') limit 1
$$;
create or replace function public.hq_submit(p_secret text,p_match text,p_sets jsonb,p_home text,p_away text) returns uuid language plpgsql security definer set search_path=public as $$
declare t public.hq_tokens%rowtype;m jsonb; d jsonb;rid uuid;
begin
 select * into t from public.hq_tokens where active and secret_hash=encode(digest(coalesce(p_secret,''),'sha256'),'hex');
 if not found then raise exception 'Invalid or revoked referee link'; end if;
 select data into d from public.hq_state where id='harvest-crown';
 if d is null or d->>'status' not in ('published','live') then raise exception 'Tournament not open for reporting'; end if;
 select value into m from jsonb_array_elements(d->'matches') where value->>'id'=p_match limit 1;
 if m is null or m->>'home' is distinct from p_home or m->>'away' is distinct from p_away or m->>'home' is null or m->>'away' is null then raise exception 'Match no longer available'; end if;
 if m->>'official' is distinct from coalesce((select r->>'id' from jsonb_array_elements(d->'refs') r where r->>'name'=t.name limit 1),'') and m->>'official' is distinct from coalesce((select 'team:' || a->>'id' from jsonb_array_elements(d->'teams') a where a->>'name'=t.name limit 1),'') and coalesce(m->>'official','') <> '' then raise exception 'This referee is not assigned to the match'; end if;
 if jsonb_typeof(p_sets) <> 'array' or jsonb_array_length(p_sets)<1 or jsonb_array_length(p_sets)>5 then raise exception 'Invalid set data'; end if;
 if exists(select 1 from public.hq_reports where match_id=p_match and status='pending') then raise exception 'A score is already pending approval'; end if;
 insert into public.hq_reports(match_id,reporter,token_id,sets,home,away) values(p_match,t.name,t.id,p_sets,p_home,p_away) returning id into rid;
 return rid;
end $$;
create or replace function public.hq_pending() returns jsonb language sql stable security definer set search_path=public as $$
 select coalesce(jsonb_agg(jsonb_build_object('id',id,'match_id',match_id,'reporter_name',reporter,'sets',sets,'match_home',home,'match_away',away,'status',status,'created_at',created_at) order by created_at),'[]'::jsonb) from public.hq_reports where status='pending' and public.hq_my_role() in ('director','assistant')
$$;
create or replace function public.hq_decide(p_report uuid,p_approve boolean,p_data jsonb,p_expected bigint) returns bigint language plpgsql security definer set search_path=public as $$
declare rec public.hq_reports%rowtype; v bigint; r text; old_data jsonb; changed jsonb;
begin
 r:=public.hq_my_role();if r not in ('director','assistant') then raise exception 'Not authorized'; end if;
 select * into rec from public.hq_reports where id=p_report for update;
 if not found or rec.status<>'pending' then raise exception 'Report already processed'; end if;
 if p_approve then
  if p_data is null or p_data->>'schema'<>'2' then raise exception 'Invalid state'; end if;
  select data into old_data from public.hq_state where id='harvest-crown' and version=p_expected;
  if old_data is null then raise exception 'State changed: reload and review'; end if;
  if not exists(select 1 from jsonb_array_elements(p_data->'matches') m where m->>'id'=rec.match_id and m->'sets'=rec.sets and m->>'home'=rec.home and m->>'away'=rec.away) then raise exception 'Approved score does not match the submitted report'; end if;
  if r='assistant' then
   if (p_data-'matches'-'audit'-'version'-'revision') is distinct from (old_data-'matches'-'audit'-'version'-'revision') then raise exception 'Assistant cannot change tournament settings'; end if;
   if exists(select 1 from jsonb_array_elements(old_data->'matches') a join jsonb_array_elements(p_data->'matches') b on a->>'id'=b->>'id' where a->>'id'<>rec.match_id and (a-'home'-'away') is distinct from (b-'home'-'away')) then raise exception 'Assistant cannot alter other match results or assignments'; end if;
  end if;
  update public.hq_state set data=p_data,version=version+1,updated_at=now() where id='harvest-crown' and version=p_expected returning version into v;
  if v is null then raise exception 'State changed: reload and review';end if;
 else
  select version into v from public.hq_state where id='harvest-crown';
 end if;
 update public.hq_reports set status=case when p_approve then 'approved' else 'rejected' end,decided_by=auth.jwt()->>'email',decided_at=now() where id=p_report;
 insert into public.hq_activity(actor,action,details) values(auth.jwt()->>'email',case when p_approve then 'score_approved' else 'score_rejected' end,jsonb_build_object('report',p_report,'match',rec.match_id));
 return v;
end $$;
revoke execute on function public.hq_my_role(),public.hq_save(jsonb,bigint),public.hq_issue_token(text),public.hq_revoke_token(text),public.hq_pending(),public.hq_decide(uuid,boolean,jsonb,bigint) from public;
grant execute on function public.hq_my_role(),public.hq_save(jsonb,bigint),public.hq_issue_token(text),public.hq_revoke_token(text),public.hq_pending(),public.hq_decide(uuid,boolean,jsonb,bigint) to authenticated;
grant execute on function public.hq_view(),public.hq_ref_identity(text),public.hq_submit(text,text,jsonb,text,text) to anon,authenticated;
